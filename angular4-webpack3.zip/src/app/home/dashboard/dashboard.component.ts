import { Component,OnInit } from '@angular/core';


@Component({
	selector: 'dashboard-app',
	templateUrl: 'dashboard.component.html',
	styleUrls: []
})
export class DashboardComponent implements OnInit {
	 constructor(){}
	 ngOnInit(){

	 }

}
