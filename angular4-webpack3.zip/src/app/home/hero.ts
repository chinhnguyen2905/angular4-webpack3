export class Hero{
    id: Number;
    name:String;
    constructor(id:number,name:String){

    }
}