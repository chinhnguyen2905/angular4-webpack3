import { Component } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'products',
	templateUrl: 'products.component.html',
	styleUrls: ['products.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class ProductsComponent {
    
}
