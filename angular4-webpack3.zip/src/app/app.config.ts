import { Injectable } from '@angular/core';

@Injectable()
export class AppConfig {
    API_URL: string;
}