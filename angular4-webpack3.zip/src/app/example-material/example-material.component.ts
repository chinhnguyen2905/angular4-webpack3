import { Component,ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'products',
	templateUrl: 'example-material.component.html',
	styleUrls: ['example-material.component.scss']
	
})
export class ExampleMaterialComponent {
     
}
