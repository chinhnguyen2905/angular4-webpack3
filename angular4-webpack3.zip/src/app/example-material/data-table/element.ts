export class Element{
     position: number;
     name: string;
     weight: number;
     symbol: string;
}