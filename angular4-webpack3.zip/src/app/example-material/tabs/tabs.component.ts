import { Component,OnInit } from '@angular/core';


@Component({
	selector: 'tabs-app',
	templateUrl: 'tabs.component.html',
	styleUrls: ['tabs.component.scss']
	
})
export class TabsComponent implements OnInit  {
     constructor(){

	 }
	 ngOnInit(){

	 }

}
