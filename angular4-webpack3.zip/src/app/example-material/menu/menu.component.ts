import { Component,OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'menu-material-app',
	templateUrl: 'menu.component.html',
    styleUrls: ['menu.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class MenuMaterialComponent {
     constructor(){

     }
     ngOnInit(){

    }
}
