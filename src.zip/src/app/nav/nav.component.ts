import { Component } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'navmenu',
	templateUrl: 'nav.component.html',
	styleUrls: ['nav.component.scss']
	
})
export class NavComponent {
     
}
