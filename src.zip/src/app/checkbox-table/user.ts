export interface User {
    name: string;
    position: number;
    weight: number;
    symbol: string;
  }